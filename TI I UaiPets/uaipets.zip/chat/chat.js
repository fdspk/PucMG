var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);

app.get('/chat', (req, res) => {
  res.sendFile(__dirname + '/chat.html');
});

io.on('connection', (socket) => {
  console.log('User Online');
  
  socket.on('codeboard-message', (msg) => {
    console.log('message: ' + msg);
	socket.broadcast.emit('message-from-others', msg);
  });
  
});

var server_port = process.env.YOUR_PORT || process.env.PORT || 3000;
http.listen(server_port, () => {
  console.log('listening on *:' + server_port);
});


//Local Storage

function leMsg () {
  let strMsg = localStorage.getItem('db');
  let objMsg = {enviarmsg};

  if (strMsg) {
      objMsg = JSON.parse (strMsg);
  }
  else {
      objMsg = { enviarMsg: [
                  ]}
  }

  return objMSG;
}

function salvaMsg (dados) {
  localStorage.setItem ('db', JSON.stringify (dados));
}

function incluirMsg (){
  // Ler os dados do localStorage
  let objMSG = leMsg();

  // Incluir novos dados
  let strMsg = document.getElementById ('typing-box').value;

  let novaMsg = {
      msg: strMsg,

  };
  objMSG.enviarMsg.push (novaMsg);

  // Salvar os dados no localStorage novamente
  salvaMsg (objMsg);

  // Atualiza os dados da tela
  imprimeMsg ();
}
// Configura os botões
document.getElementById ('btnMsg').addEventListener ('click', incluirMsg);










